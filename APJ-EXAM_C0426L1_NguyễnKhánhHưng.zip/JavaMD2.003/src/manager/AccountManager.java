package manager;

import exception.NotFoundBankAccountException;
import model.BankAccount;
import model.PaymentAccount;
import model.SavingsAccount;
import util.FileHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AccountManager {
    private final Scanner scanner = new Scanner(System.in);

    // 1. Thêm mới tài khoản
    public void addAccount() {
        List<BankAccount> accounts = FileHelper.readAccounts();

        // Tự động tăng ID
        int nextId = accounts.isEmpty() ? 1 : accounts.get(accounts.size() - 1).getId() + 1;

        System.out.println("--- THÊM MỚI TÀI KHOẢN NGÂN HÀNG ---");
        System.out.println("1. Tài khoản tiết kiệm");
        System.out.println("2. Tài khoản thanh toán");
        System.out.print("Chọn loại tài khoản: ");
        String type = scanner.nextLine();

        if (!type.equals("1") && !type.equals("2")) {
            System.out.println("Lựa chọn không hợp lệ!");
            return;
        }

        String code = inputNonEmpty("Nhập Mã tài khoản: ");
        String name = inputNonEmpty("Nhập Tên chủ tài khoản: ");
        String date = inputNonEmpty("Nhập Ngày tạo tài khoản (dd/MM/yyyy): ");

        if (type.equals("1")) {
            double depositAmount = inputPositiveDouble("Nhập Số tiền gửi tiết kiệm (> 0): ");
            String depositDate = inputNonEmpty("Nhập Ngày gửi tiết kiệm (dd/MM/yyyy): ");
            double rate = inputPositiveDouble("Nhập Lãi suất (%): ");
            int term = (int) inputPositiveDouble("Nhập Kỳ hạn (tháng): ");

            SavingsAccount sa = new SavingsAccount(nextId, code, name, date, depositAmount, depositDate, rate, term);
            accounts.add(sa);
        } else {
            String cardNumber = inputCardNumber();
            double balance = inputPositiveDouble("Nhập Số tiền trong tài khoản (> 0): ");

            PaymentAccount pa = new PaymentAccount(nextId, code, name, date, cardNumber, balance);
            accounts.add(pa);
        }

        FileHelper.writeAccounts(accounts);
        System.out.println("Thêm mới tài khoản thành công!");
    }

    // 2. Xóa tài khoản
    public void deleteAccount() {
        while (true) {
            List<BankAccount> accounts = FileHelper.readAccounts();
            System.out.print("Nhập Mã tài khoản ngân hàng cần xóa (hoặc nhấn Enter để quay lại Menu chính): ");
            String code = scanner.nextLine().trim();

            if (code.isEmpty()) {
                return;
            }

            try {
                BankAccount target = null;
                for (BankAccount acc : accounts) {
                    if (acc.getAccountCode().equalsIgnoreCase(code)) {
                        target = acc;
                        break;
                    }
                }

                if (target == null) {
                    throw new NotFoundBankAccountException("Tài khoản không tồn tại.");
                }

                System.out.print("Bạn có chắc chắn muốn xóa tài khoản này không? (Yes/No): ");
                String confirm = scanner.nextLine().trim();

                if (confirm.equalsIgnoreCase("Yes")) {
                    accounts.remove(target);
                    FileHelper.writeAccounts(accounts);
                    System.out.println("Xóa tài khoản thành công!\n");
                    System.out.println("--- DANH SÁCH TÀI KHOẢN SAU KHI XÓA ---");
                    displayAccounts();
                } else {
                    System.out.println("Hủy bỏ thao tác xóa.");
                }
                break; // Thoát vòng lặp sau khi hoàn tất thao tác xóa
            } catch (NotFoundBankAccountException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    // 3. Xem danh sách tài khoản
    public void displayAccounts() {
        List<BankAccount> accounts = FileHelper.readAccounts();
        if (accounts.isEmpty()) {
            System.out.println("Danh sách tài khoản rỗng!");
            return;
        }

        System.out.println("--- DANH SÁCH TÀI KHOẢN NGÂN HÀNG ---");
        for (BankAccount acc : accounts) {
            System.out.println(acc.getInfo());
        }
    }

    // 4. Tìm kiếm tài khoản
    public void searchAccount() {
        List<BankAccount> accounts = FileHelper.readAccounts();
        System.out.print("Nhập từ khóa tìm kiếm (Mã tài khoản hoặc Tên chủ tài khoản): ");
        String keyword = scanner.nextLine().trim().toLowerCase();

        List<BankAccount> results = new ArrayList<>();
        for (BankAccount acc : accounts) {
            if (acc.getAccountCode().toLowerCase().contains(keyword) ||
                    acc.getAccountHolderName().toLowerCase().contains(keyword)) {
                results.add(acc);
            }
        }

        if (results.isEmpty()) {
            System.out.println("Không tìm thấy tài khoản phù hợp!");
        } else {
            System.out.println("--- KẾT QUẢ TÌM KIẾM ---");
            for (BankAccount acc : results) {
                System.out.println(acc.getInfo());
            }
        }
    }

    // --- CÁC HÀM VALIDATE DỮ LIỆU ---
    private String inputNonEmpty(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                return input;
            }
            System.out.println("Trường này là bắt buộc, không được để trống!");
        }
    }

    private double inputPositiveDouble(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                String input = scanner.nextLine().trim();
                if (input.isEmpty()) {
                    System.out.println("Trường này là bắt buộc!");
                    continue;
                }
                double val = Double.parseDouble(input);
                if (val > 0) {
                    return val;
                }
                System.out.println("Giá trị phải là số dương (> 0)!");
            } catch (NumberFormatException e) {
                System.out.println("Vui lòng nhập đúng định dạng số!");
            }
        }
    }

    private String inputCardNumber() {
        while (true) {
            System.out.print("Nhập Số thẻ: ");
            String input = scanner.nextLine().trim();
            if (input.isEmpty()) {
                System.out.println("Trường này là bắt buộc!");
                continue;
            }
            try {
                double val = Double.parseDouble(input);
                if (val > 0) {
                    return input;
                }
                System.out.println("Số thẻ phải là số dương!");
            } catch (NumberFormatException e) {
                System.out.println("Số thẻ chỉ được chứa ký tự số!");
            }
        }
    }
}