package main;

import manager.AccountManager;

import java.util.Arrays;
import java.util.Scanner;

import static java.lang.System.*;

public class Main {
    public static void main(String[] args) {
        AccountManager manager = new AccountManager();
        Scanner scanner = new Scanner(in);

        while (true) {
            for (String string : Arrays.asList("Chọn chức năng theo số (để tiếp tục):", "1. Thêm mới", "2. Xóa")) {
                out.println(string);
            }
            for (String s : Arrays.asList("3. Xem danh sách các tài khoản ngân hàng", "4. Tìm kiếm", "5. Thoát")) {
                out.println(s);
            }
            out.print("Chọn chức năng: ");

            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    manager.addAccount();
                    break;
                case "2":
                    manager.deleteAccount();
                    break;
                case "3":
                    manager.displayAccounts();
                    break;
                case "4":
                    manager.searchAccount();
                    break;
                case "5":
                    out.println("Đã thoát chương trình.");
                    exit(0);
                    break;
                default:
                    out.println("Lựa chọn không hợp lệ! Vui lòng chọn lại.");
            }
        }
    }
}