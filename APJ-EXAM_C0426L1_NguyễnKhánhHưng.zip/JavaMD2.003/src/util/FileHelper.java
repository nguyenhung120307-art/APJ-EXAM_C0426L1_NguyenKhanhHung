package util;

import model.BankAccount;
import model.PaymentAccount;
import model.SavingsAccount;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileHelper {
    private static final String FILE_PATH = "data/bank_accounts.csv";

    public static List<BankAccount> readAccounts() {
        List<BankAccount> accounts = new ArrayList<>();
        File file = new File(FILE_PATH);

        if (!file.exists()) {
            return accounts;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;

                String[] data = line.split(",");
                if (data.length == 8) { // Tài khoản tiết kiệm (8 thuộc tính)
                    int id = Integer.parseInt(data[0].trim());
                    String accountCode = data[1].trim();
                    String name = data[2].trim();
                    String createDate = data[3].trim();
                    double deposit = Double.parseDouble(data[4].trim());
                    String depositDate = data[5].trim();
                    double rate = Double.parseDouble(data[6].trim());
                    int term = Integer.parseInt(data[7].trim());

                    accounts.add(new SavingsAccount(id, accountCode, name, createDate, deposit, depositDate, rate, term));
                } else if (data.length == 6) { // Tài khoản thanh toán (6 thuộc tính)
                    int id = Integer.parseInt(data[0].trim());
                    String accountCode = data[1].trim();
                    String name = data[2].trim();
                    String createDate = data[3].trim();
                    String cardNumber = data[4].trim();
                    double balance = Double.parseDouble(data[5].trim());

                    accounts.add(new PaymentAccount(id, accountCode, name, createDate, cardNumber, balance));
                }
            }
        } catch (IOException e) {
            System.err.println("Lỗi đọc file: " + e.getMessage());
        }

        return accounts;
    }

    public static void writeAccounts(List<BankAccount> accounts) {
        File file = new File("data");
        if (!file.exists()) {
            boolean mkdirs = file.mkdirs();
        }

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (BankAccount acc : accounts) {
                bw.write(acc.toCSV());
                bw.newLine();
            }
        } catch (IOException e) {
            System.err.println("Lỗi ghi file: " + e.getMessage());
        }
    }
}