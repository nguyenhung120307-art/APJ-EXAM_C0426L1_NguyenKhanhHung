package model;

public abstract class BankAccount {
    private final int id;
    private final String accountCode;
    private final String accountHolderName;
    private final String creationDate;

    public BankAccount(int id, String accountCode, String accountHolderName, String creationDate) {
        this.id = id;
        this.accountCode = accountCode;
        this.accountHolderName = accountHolderName;
        this.creationDate = creationDate;
    }

    public int getId() {
        return id;
    }

    public String getAccountCode() {
        return accountCode;
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public abstract String toCSV();

    public abstract String getInfo();

    @Override
    public String toString() {
        return String.format("ID: %d | Mã TK: %s | Chủ TK: %s | Ngày tạo: %s",
                id, accountCode, accountHolderName, creationDate);
    }
}