package model;

public class PaymentAccount extends BankAccount {
    private final String cardNumber;
    private final double accountBalance;

    public PaymentAccount(int id, String accountCode, String accountHolderName, String creationDate,
                          String cardNumber, double accountBalance) {
        super(id, accountCode, accountHolderName, creationDate);
        this.cardNumber = cardNumber;
        this.accountBalance = accountBalance;
    }

    @Override
    public String toCSV() {
        return String.format("%d,%s,%s,%s,%s,%.0f",
                getId(), getAccountCode(), getAccountHolderName(), getCreationDate(),
                cardNumber, accountBalance);
    }

    @Override
    public String getInfo() {
        return String.format("%s | Số thẻ: %s | Số tiền: %.0f",
                super.toString(), cardNumber, accountBalance);
    }
}