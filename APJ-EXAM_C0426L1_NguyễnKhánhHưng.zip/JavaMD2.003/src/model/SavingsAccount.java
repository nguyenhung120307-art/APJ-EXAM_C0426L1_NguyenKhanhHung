package model;

public class SavingsAccount extends BankAccount {
    private final double depositAmount;
    private final String depositDate;
    private final double interestRate;
    private final int term;

    public SavingsAccount(int id, String accountCode, String accountHolderName, String creationDate,
                          double depositAmount, String depositDate, double interestRate, int term) {
        super(id, accountCode, accountHolderName, creationDate);
        this.depositAmount = depositAmount;
        this.depositDate = depositDate;
        this.interestRate = interestRate;
        this.term = term;
    }

    @Override
    public String toCSV() {
        return String.format("%d,%s,%s,%s,%.0f,%s,%.2f,%d",
                getId(), getAccountCode(), getAccountHolderName(), getCreationDate(),
                depositAmount, depositDate, interestRate, term);
    }

    @Override
    public String getInfo() {
        return String.format("%s | Tiền gửi: %.0f | Ngày gửi: %s | Lãi suất: %.2f%% | Kỳ hạn: %d tháng",
                super.toString(), depositAmount, depositDate, interestRate, term);
    }
}